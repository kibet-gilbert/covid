import argparse
import pandas as pd


def parse_args(argv=None):
    # Create argument parser
    parser = argparse.ArgumentParser()

    # Positional mandatory arguments
    parser.add_argument(
        "barcode_counts",
        help="Input TSV containing aggregated reads counts per RBK and \
              FIP barcode",
        type=str,
    )

    parser.add_argument(
        "call_table",
        help="Output TSV containing the contents of barcode_counts with \
              a call column for Positive, Negative, Inconclusive, or Invalid",
        type=str,
    )

    # Optional arguments
    thresh = parser.add_argument_group("thresholding options")
    thresh.add_argument(
        "--validity_threshold",
        help="The minimum number of total classified reads (target + control) \
              for a sample result to be considered a valid test. If not met, \
              a result of 'Invalid' is returned [50]",
        type=int,
        default=50,
    )
    thresh.add_argument(
        "-m",
        "--method",
        help="Whether to use threshold based on target absolute read \
              counts ('absolute') or read proportions ('proportion') \
              ('absolute' recommended) [absolute]",
        type=str,
        default="absolute",
    )
    thresh.add_argument(
        "--min_pos_count",
        help="If --method=absolute, the minimum target read count \
              required for a sample to return a 'Positive' result [50]",
        type=int,
        default=50,
    )
    thresh.add_argument(
        "--max_neg_count",
        help="If --method=absolute, the maximum target read count \
              required for a sample to return a 'Negative' result. \
              Samples where MAX_NEG_COUNT <= absolute_count < MIN_POS_COUNT \
              are considered 'Inconclusive' [20]",
        type=int,
        default=20,
    )
    thresh.add_argument(
        "--min_pos_fraction",
        help="If --method=proportion, the minimum target read \
              fraction of classified reads (target + control) \
              required for a sample to return a 'Positive' result [0.4]",
        type=float,
        default=0.4,
    )
    thresh.add_argument(
        "--max_neg_fraction",
        help="If --method=proportion, the maximum target read fraction \
              of classified reads (target + control) required for a \
              sample to return a 'Negative' result. Samples where \
              MAX_NEG_FRACTION < target_fraction < MIN_POS_FRACTION \
              are considered 'Inconclusive' [0.25]",
        type=float,
        default=0.25,
    )
    thresh.add_argument(
        "--correction_factor",
        help="Correction factor (0-1) for subtraction portion of \
              unclassified reads from the sum of on-target reads \
              (not recommended) [0]",
        type=float,
        default=0,
    )

    other = parser.add_argument_group("additional options")
    other.add_argument(
        "-t",
        "--target",
        help="Name of the target genome [nCoV2019]",
        type=str,
        default="nCoV2019",
    )
    other.add_argument(
        "-c",
        "--control",
        help="Name of the positive control (target_<genome>_<primer>) \
              [target_human_ACTB]",
        type=str,
        default="target_human_ACTB",
    )
    other.add_argument(
        "-s",
        "--sample_sheet",
        help="Optionally include tab-delimited sample sheet with \
              sample details, well address, CT values, etc) [None]",
        type=str,
        default=None,
    )
    other.add_argument(
        "--sample_cols",
        help="If using --sample_sheet, specify which columns to include \
              alongside calls (e.g. sample_id,viral_titer) [sample_id]",
        type=str,
        default="sample_id",
    )

    # Parse arguments
    args = parser.parse_args(argv)

    return args


def drop_unclassified(df):
    """
    Drop unclassified FIP barcodes from results
    """
    rows = [r for r in df["barcode"] if "unclassified" not in r]
    df = df[df["barcode"].isin(rows)]
    return df


def apply_target_count_correction(df, ncov_cols, args):
    """
    Apply the specified correction to subtract a fraction
    of the target_unclassified reads from the target sum
    """
    target_sum = "{}_sum".format(args.target)
    target_sum_corr = "{}_corr".format(target_sum)

    # Get the corrected sum of on-target reads
    df[target_sum] = df.xs(ncov_cols, axis=1).sum(axis=1)
    df["correction_count"] = (
        df[target_sum] - (df["target_unclassified"] * args.correction_factor)
    ).round(1)
    df[target_sum_corr] = df["correction_count"].apply(lambda x: max(x, 0))
    df = df.drop("correction_count", axis=1)
    return df, target_sum, target_sum_corr


def apply_criteria_absolute(df, ncov_cols, args):
    """
    Given the specified criteria, make True/False/other
    calls in the dataframe
    """
    # Look for any positive calls across targets
    ncov_sum = df.xs(ncov_cols, axis=1).sum(axis=1)
    df["call"] = "Inconclusive"
    df.loc[ncov_sum >= args.min_pos_count, "call"] = "Positive"
    df.loc[ncov_sum < args.max_neg_count, "call"] = "Negative"
    return df


def apply_criteria_proportion(df, ncov_cols, args):
    """
    Given the specified criteria, make True/False/other
    calls in the dataframe
    """
    if args.correction_factor != 0:
        df, target_sum, target_sum_corr = apply_target_count_correction(
            df, ncov_cols, args
        )
    else:
        target_sum = "{}_sum".format(args.target)
        target_sum_corr = target_sum
        df[target_sum] = df.xs(ncov_cols, axis=1).sum(axis=1)

    # Compute the fraction of all classified reads
    # that are on-target reads
    df["classified_sum"] = df.xs([target_sum_corr, args.control], axis=1).sum(axis=1)
    df["positive_fraction"] = (df[target_sum_corr] / df["classified_sum"]).round(4)

    df["call"] = "Inconclusive"
    df.loc[df["positive_fraction"] >= args.min_pos_fraction, "call"] = "Positive"
    df.loc[df["positive_fraction"] < args.max_neg_fraction, "call"] = "Negative"

    df = df.drop([target_sum, "classified_sum"], axis=1)
    return df


def check_sample_failure(df, args):
    """
    If the sample is negative for classified reads either
    target or control reads, consider the reaction failed.
    Also classify marginal positive calls as inconclusive.
    """
    target_cols = list(df.columns[df.columns.str.contains("target_")])
    target_cols = [
        t
        for t in target_cols
        if (t.find("_unclassified") < 0) & (t.find("_fraction") < 0)
    ]

    # Overwrite pos/neg/inconclusive results if failed
    if args.correction_factor != 0:
        fail_idx = (
            (
                df.xs(target_cols, axis=1).sum(axis=1)
                - df["target_unclassified"] * args.correction_factor
            ).round(1)
        ) < args.validity_threshold
    else:
        fail_idx = df.xs(target_cols, axis=1).sum(axis=1) < args.validity_threshold
    df.loc[fail_idx, "call"] = "Invalid"
    return df


def main(args=None):
    if not args:
        args = parse_args()

    df = pd.read_csv(args.barcode_counts, sep="\t")
    df = drop_unclassified(df)

    ncov_cols = list(df.columns[df.columns.str.contains(args.target)])
    if args.method == "absolute":
        df = apply_criteria_absolute(df, ncov_cols, args)
    else:
        df = apply_criteria_proportion(df, ncov_cols, args)

    df = check_sample_failure(df, args)

    output_cols = list(df.columns.values)

    df["rbk_barcode"] = df["barcode"].apply(
        lambda x: x.split("_")[0].replace("barcode", "RBK")
    )
    df["fip_barcode"] = df["barcode"].apply(lambda x: x.split("_")[1])

    if args.sample_sheet != None:
        df_sample = pd.read_csv(args.sample_sheet, sep="\t").fillna("NULL")
        df_sample["barcode"] = df_sample[["rbk_barcode", "fip_barcode"]].apply(
            lambda x: "_".join(x).replace("RBK", "barcode"), axis=1
        )
        df = pd.merge(df, df_sample, on="barcode", how="outer")
        # If pipeline did not generate results for entry in
        # sample sheet, consider the sample failed
        df.loc[:, "call"] = df.xs("call", axis=1).fillna("Invalid")
        df = df.fillna(0)
        output_cols.extend(args.sample_cols.split(","))

    df = df.xs(output_cols, axis=1)
    df.to_csv(args.call_table, sep="\t", index=False)


if __name__ == "__main__":
    main()
