"""
Script to generate various reports from .tsv and barcode_count files produced as
part of LamPORE analysis.
"""
import argparse
import subprocess
import shutil
import typing
from pathlib import Path

import pandas as pd
import pkg_resources
import tabulate


# Borrowed from later versions of pandas
# https://github.com/pandas-dev/pandas/blob/v1.0.5/pandas/core/frame.py#L1996
def _to_markdown(dataframe: pd.DataFrame, **kwargs) -> typing.Optional[str]:
    kwargs.setdefault("headers", "keys")
    kwargs.setdefault("tablefmt", "pipe")
    result = tabulate.tabulate(dataframe, **kwargs)
    return result


def _get_barcode_results_from_input(input_counts_table: pd.DataFrame) -> pd.DataFrame:
    result_df = input_counts_table[["barcode", "call"]]
    return result_df.rename(columns={"call": "Result"})


def _get_summary_fields(
    summary_fields: typing.Dict[str, str], input_counts_table: pd.DataFrame
) -> pd.DataFrame:
    drop_fields = [
        "fast5_files_in_final_dest",
        "fastq_files_in_final_dest",
        "fastq_files_in_fallback",
        "fast5_files_in_fallback",
        "basecalling_enabled",
        "protocol_run_id",
        "sequencing_summary_file",
    ]

    rename_fields = dict(
        instrument="Instrument",
        position="Position",
        flow_cell_id="Flow Cell ID",
        sample_id="Sample ID",
        protocol="Protocol",
        protocol_group_id="Experiment Name",
        acquisition_run_id="Acquisition Run ID",
        started="Started",
        acquisition_stopped="Run Ended",
        processing_stopped="Analysis Ended",
        sequencing_summary_file="Sequencing Summary File",
    )

    # Trim summary times to sensible length:
    for ts_field in ["started", "acquisition_stopped", "processing_stopped"]:
        if ts_field not in summary_fields:
            continue
        summary_fields[ts_field] = (
            summary_fields[ts_field].split(".", 1)[0].replace("T", " ")
        )

    # Use nice title case for names:
    title_summary_fields = []
    for field, value in summary_fields.items():
        if field in drop_fields:
            continue
        title_summary_fields.append((rename_fields.get(field, field), value))

    call_summary_dict = input_counts_table["call"].value_counts().to_dict()
    for key, val in call_summary_dict.items():
        title_summary_fields.append(("{key} Samples".format(key=key), val))

    summary_df = pd.DataFrame(title_summary_fields, columns=["Key", "Value"])
    return summary_df


def generate_md_report(
    input_counts_table: pd.DataFrame,
    summary_fields: typing.Dict[str, str],
    output_path: Path,
):
    """ Generate a markdown report summarising a LamPORE run.

    :param input_counts_table: A DataFrame of a barcode_counts file.
    :type input_counts_table: pd.DataFrame
    :param summary_fields: A set of summary fields to include in the report.
    :type summary_fields: typing.Dict[str, str]
    :param output_path: Path to the output report file.
    :type output_path: Path

    """
    result_df = _get_barcode_results_from_input(input_counts_table)
    result_table = _to_markdown(result_df)

    summary_table = _to_markdown(
        _get_summary_fields(summary_fields, input_counts_table)
    )

    report_txt = "# Run Summary\n\n{summary_table}\n\n# Sample Results\n\n{result_table}\n".format(
        summary_table=summary_table, result_table=result_table
    )
    if not output_path.parent.exists():
        output_path.parent.mkdir(parents=True)
    with open(str(output_path), "w") as file_handle:
        file_handle.write(report_txt)


def generate_pdf_report(
    input_counts_table: pd.DataFrame,
    summary_fields: typing.Dict[str, str],
    output_pdf_report: Path,
):
    """ Generate a pdf report summarising a LamPORE run.

    :param input_counts_table: A DataFrame of a barcode_counts file.
    :type input_counts_table: pd.DataFrame
    :param summary_fields: A set of summary fields to include in the report.
    :type summary_fields: typing.Dict[str, str]
    :param output_pdf_report: Path to the output report file.
    :type output_pdf_report: Path

    """
    if shutil.which("pdflatex") is None:
        raise RuntimeError("pdflatex not found -- cannot generate pdf report")

    report_time = pd.Timestamp.now().isoformat(sep=" ").rsplit(":", 1)[0]

    result_df = _get_barcode_results_from_input(input_counts_table)
    summary_df = _get_summary_fields(summary_fields, input_counts_table)

    latex_template = Path(
        pkg_resources.resource_filename(
            "lampore_analysis", "resources/template/report.tex"
        )
    ).read_text()
    ont_logo = pkg_resources.resource_filename(
        "lampore_analysis", "resources/template/ont-logo.png"
    )
    lampore_logo = pkg_resources.resource_filename(
        "lampore_analysis", "resources/template/lampore-logo.png"
    )
    if not output_pdf_report.parent.exists():
        output_pdf_report.parent.mkdir(parents=True)
    tmp_tex = output_pdf_report.with_suffix(".tex")
    with open(str(tmp_tex), "w") as file_handle:
        with pd.option_context("max_colwidth", 512):
            file_handle.write(
                latex_template.format(
                    summary_table=summary_df.to_latex(longtable=True),
                    result_table=result_df.to_latex(longtable=True),
                    report_time=report_time,
                    flow_cell_id=summary_fields.get("flow_cell_id", ""),
                    run_id=summary_fields.get("acquisition_run_id", ""),
                    logo=ont_logo,
                    lampore_logo=lampore_logo,
                )
            )

    for _ in range(3):  # run multiple times for longtable
        subprocess.run(
            [
                "pdflatex",
                "-interaction=batchmode",
                "-output-directory",
                str(tmp_tex.parent),
                str(tmp_tex),
            ],
            check=True,
        )


def _read_summary_fields(final_summary: Path):
    return pd.read_csv(
        final_summary, sep="=", header=None, index_col=[0], dtype=str
    ).to_dict()[1]


def _generate_all_reports(
    called_samples_filename: Path,
    final_summary_filename: Path,
    output_markdown_filename: Path,
    output_pdf_filename: Path,
):
    input_frame = pd.read_csv(called_samples_filename, sep="\t")

    summary_fields = _read_summary_fields(final_summary_filename)

    generate_md_report(input_frame, summary_fields, output_markdown_filename)
    if output_pdf_filename is not None:
        generate_pdf_report(input_frame, summary_fields, output_pdf_filename)


def main():  # pylint: disable=missing-function-docstring
    parser = argparse.ArgumentParser()
    parser.add_argument("called_samples", type=Path)
    parser.add_argument("final_summary", type=Path)
    parser.add_argument("output_md_path", type=Path)
    parser.add_argument("output_pdf_path", nargs="?", type=Path)

    args = parser.parse_args()
    _generate_all_reports(
        args.called_samples,
        args.final_summary,
        args.output_md_path,
        args.output_pdf_path,
    )


if __name__ == "__main__":
    main()
