"""
Translate from a sequencing_summary.txt file produced by guppy to a
barcode_counts file with aggregated LamPORE barcoding statistics, suitable for
input into the call_samples.py script.
"""
import argparse
from collections import OrderedDict
import copy
from csv import DictReader
from pathlib import Path
import typing


# A list of targets associated with a particular LamPORE protocol.
# The order of the targets is the order that their columns will be written to
# output files.
TARGETS = {"nCoV2019": ["human_ACTB", "nCoV2019_AS1", "nCoV2019_E1", "nCoV2019_N2",]}

# Used to validate input summary files
EXPECTED_SUMMARY_COLUMNS = ["barcode_arrangement", "lamp_barcode_id", "lamp_target_id"]

AggregationDict = typing.Dict[str, typing.Dict[str, int]]


def _sanity_check_summary_file(filename: Path):
    with filename.open(mode="r") as file_handle:
        column_names = file_handle.readline().split("\t")
    missing_column_names = []
    for expected_column in EXPECTED_SUMMARY_COLUMNS:
        if expected_column not in column_names:
            missing_column_names.append(expected_column)
    if missing_column_names:
        raise KeyError(
            "Required columns {} not found in sequencing_summary "
            "file".format(missing_column_names)
        )


def _aggregate_summary_file(
    filename: Path, target_key: str = "nCoV2019",
) -> AggregationDict:
    all_targets = copy.copy(TARGETS[target_key])
    all_targets.append("unclassified")
    results = {}
    barcode_entry = {target: 0 for target in all_targets}

    with filename.open(mode="r") as file_handle:
        reader = DictReader(file_handle, delimiter="\t")
        for entry in reader:
            key = "{}_{}".format(entry["barcode_arrangement"], entry["lamp_barcode_id"])
            if key not in results:
                results[key] = copy.copy(barcode_entry)
            results[key][entry["lamp_target_id"]] += 1

    return results


def _get_target_map(target_key: str = "nCoV2019"):
    target_map = OrderedDict()
    for target in TARGETS[target_key]:
        target_map["target_{}".format(target)] = target
    # We always have an "unclassified" target available
    target_map["target_unclassified"] = "unclassified"

    return target_map


def _write_results_to_file(
    results: AggregationDict, filename: Path, target_key: str = "nCoV2019",
):
    target_map = _get_target_map(target_key)
    columns = ["barcode"] + list(target_map.keys())
    with filename.open(mode="w+") as file_handle:
        file_handle.write("\t".join(columns) + "\n")
        for key in sorted(results.keys()):
            result = results[key]
            barcode = [key]
            # join() will require strings
            target_counts = [str(result[target]) for target in target_map.values()]
            file_handle.write("\t".join(barcode + target_counts) + "\n")


def generate_barcode_counts(
    sequencing_summary_file: Path, output_filename: Path, target_key: str = "nCoV2019",
):
    """ Generate a snakemake-style barcode_counts file from a
    sequencing_summary file produced by guppy.

    :param sequencing_summary_file: sequencing_summary.txt file producted by
        guppy.
    :type sequencing_summary_file: Path
    :param output_filename: Output .tsv file to save results to.
    :type output_filename: Path
    :param target_key: Name of the LamPORE analysis being used, e.g. "nCoV2019".
    :type target_key: str

    """
    _sanity_check_summary_file(sequencing_summary_file)
    results = _aggregate_summary_file(sequencing_summary_file, target_key)
    _write_results_to_file(results, output_filename, target_key)


def main():  # pylint: disable=missing-function-docstring
    available_lampore_analyses = TARGETS.keys()

    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "summary_file",
        help=(
            "Path to a sequencing_summary.txt or barcoding_summary.txt file "
            "produced by guppy when running LamPORE detection."
        ),
        type=Path,
    )
    parser.add_argument(
        "output_filename",
        help="Output .tsv file to save barcode counts to.",
        type=Path,
    )
    parser.add_argument(
        "lampore_analysis_type",
        help="Name of the LamPORE analysis used.",
        nargs="?",
        choices=available_lampore_analyses,
        default="nCoV2019",
        type=str,
    )

    args = parser.parse_args()

    generate_barcode_counts(
        args.summary_file, args.output_filename, args.lampore_analysis_type
    )


if __name__ == "__main__":
    main()
